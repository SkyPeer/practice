A Pen created at CodePen.io. You can find this one at https://codepen.io/fantaskis/pen/XqoqNM.

 Here's a little toggle I whipped up. It's more art than function:) 